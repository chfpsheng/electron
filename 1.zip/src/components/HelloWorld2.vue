<template>
  <!-- <el-table :data="tableData" style="width: 100%">
    <el-table-column prop="date" label="Date" width="180" />
    <el-table-column prop="name" label="Name" width="180" />
    <el-table-column prop="address" label="Address" />
  </el-table> -->
  <div></div>
</template>
<script  setup>
import { onMounted, reactive, ref } from 'vue'
// ​import axios from "axios";
export default {
  setup() {
    //let tableData = ref(0)
    
​
    
    // onMounted(() => {
    //   axios({
    //       method: 'get',  //请求方式，默认是get请求
    //       url:'http://localhost:30000/users/', //地址
    //   }).then(res=>{
    //           console.log(3333,res)
    //         })
    // })
   
    // return {
    //   tableData
    // }
    console.log(111111)
  },
}

</script>